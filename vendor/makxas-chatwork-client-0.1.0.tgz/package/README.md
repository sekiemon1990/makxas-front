# @makxas/chatwork-client

Shared Chatwork API client for makxas internal tools.

## Install

From a packed tarball:

```bash
pnpm add file:./makxas-chatwork-client-0.1.0.tgz
```

Inside the `chatwork-mcp` workspace:

```bash
pnpm add @makxas/chatwork-client@workspace:*
```

## API

### ChatworkClient

```ts
import { ChatworkClient } from "@makxas/chatwork-client";

const client = new ChatworkClient({ token: process.env.CHATWORK_API_TOKEN! });
const rooms = await client.listRooms();
```

### sendChatworkMessage

```ts
import { sendChatworkMessage } from "@makxas/chatwork-client";

const result = await sendChatworkMessage(123456, "[info]Hello[/info]");
if (!result.ok) console.error(result.error);
```

### cw helpers

```ts
import { composeInfoMessage, cw } from "@makxas/chatwork-client";

const body = [
  cw.infoOpen("通知"),
  cw.code("important"),
  cw.hr(),
  "詳細: https://example.test",
  cw.infoClose(),
].join("\n");

const info = composeInfoMessage({
  title: "新規受注",
  lines: ["チャネル: メルカリ", "販売金額: ¥98,000"],
  link: { label: "受注を開く", url: "https://example.test/orders/1" },
});
```
